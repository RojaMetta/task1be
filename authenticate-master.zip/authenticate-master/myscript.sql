CREATE DATABASE notedb;
USE notedb;

CREATE TABLE User ( email VARCHAR(20) primary key,
 password VARCHAR(10) , 
 address VARCHAR(20),
 mobileNo VARCHAR(10)
 );
 
INSERT INTO User VALUES('rajib@gmail.com','rajib123','delhi','8978612345');
commit;
SELECT * FROM User;



