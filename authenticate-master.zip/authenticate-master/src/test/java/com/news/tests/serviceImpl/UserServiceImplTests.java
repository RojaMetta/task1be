package com.news.tests.serviceImpl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.news.domain.User;
import com.news.exception.UserNotFoundException;
import com.news.repository.UserRepository;
import com.news.service.UserServiceImpl;
@ExtendWith(MockitoExtension.class)
class UserServiceImplTests {

	  @Mock
	    UserRepository userRepository;

	    @InjectMocks
	    UserServiceImpl userService;
	    
	    @Test
	    public void givenValidUserIDThenShouldReturnUser() throws UserNotFoundException{
	    	User user=new User("virinchi12","vk@gmail.com","123456","Fav food?","Burger","Timon and?","pumba");
	    	Optional<User> optionalUser = Optional.empty();
	    	when(userRepository.findById(user.getEmail())).thenReturn(optionalUser);
	    	User addedUser = userService.addUser(user);
	    	verify(userRepository,times(1)).findById("vk@gmail.com");
	        verify(userRepository,times(1)).save(user);
	    	
	    }
	    
	    

}
