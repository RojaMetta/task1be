package com.news.tests.controller;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.news.controller.UserController;
import com.news.domain.User;
import com.news.service.UserService;


import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import org.junit.jupiter.api.Test;

@ExtendWith(MockitoExtension.class)
class UserControllerTests {

	@Mock
	private UserService userService;
	
	 @InjectMocks
	    private UserController userController;

	    @Autowired
	    private MockMvc mockMvc;


	    @BeforeEach
	    public void setUp(){
	        mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
	    }

	@Test
	public void givenNewUserWhenPostThenReturnUserJSON() throws Exception{
		User user = new User("simba12","simba@gmail.com","123456","Who is king of jungle","simba","timon and?","pumba");
		when(userService.addUser(any())).thenReturn(user);
		mockMvc.perform(post("/api/v1/users/addUser")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"username\": \"simba12\", \"email\" : \"simba@gmail.com\",\"password\" : \"123456\",\"question1\" :\"Who is king of jungle\",\"ans1\":\"simba\",\"question2\":\"timon and?\",\"ans2\":\"pumba\"}"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.username").value("simba12"));
				
				
	}
	
	
}