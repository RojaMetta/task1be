package com.news.exception;

public class UserAlreadyPresentException extends Exception {

	public UserAlreadyPresentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
