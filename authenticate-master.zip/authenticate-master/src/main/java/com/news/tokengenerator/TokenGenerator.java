package com.news.tokengenerator;

import java.util.Map;

import com.news.domain.User;

@FunctionalInterface
public interface TokenGenerator {
  Map<String,String> generateToken(User user);
}
