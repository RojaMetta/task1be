package com.news.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.news.domain.User;
import com.news.exception.UserAlreadyPresentException;
import com.news.exception.UserNotFoundException;

public interface UserService {
   public User getUser(String email) throws UserNotFoundException;
   public User addUser(User user) throws UserAlreadyPresentException;
   public User  updateUser(User user) throws UserNotFoundException;
   public List<User> allUsers();
}
