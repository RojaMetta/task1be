package com.news.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.news.exception.UserAlreadyPresentException;
import com.news.exception.UserNotFoundException;

@ControllerAdvice
public class UserAlreadyPresentExceptionController {
   
    @Value(value="${data.exception.message}")
    private String errorMessage;
    
    
    @ExceptionHandler(value=UserAlreadyPresentException.class)
	public ResponseEntity<?> exception(UserAlreadyPresentException exception)
	{
    	return new ResponseEntity<String>(errorMessage,HttpStatus.NOT_FOUND);
	}
}
